/*
 * 7 Segment.c
 *
 * Created: 8/10/2018 8:06:08 PM
 * Author : Rowsoni
 */ 



#include <avr/io.h>
#include <util/delay.h>

//Configurations

//**************
// Here you may change the port in which you have connected the display
#define SEVEN_SEGMENT_PORT	PORTD
#define SEVEN_SEGMENT_DDR	DDRD


void SevenSegment(uint8_t n,uint8_t dp)
{
	/*
	This function writes a digit given by n to the display

	the decimal point is displayed if dp=1

	Note:
	n must be less than 9
	*/
	if(n<10)
	{
		switch (n)
		{
			case 0:
			SEVEN_SEGMENT_PORT=0b11000000;
			break;

			case 1:
							   //.gfedcba
			SEVEN_SEGMENT_PORT=0b11111001;
			break;

			case 2:
							   //.gfedcba
			SEVEN_SEGMENT_PORT=0b10100100;
			break;

			case 3:
							   //.gfedcba
			SEVEN_SEGMENT_PORT=0b10110000;
			break;

			case 4:
				               //.gfedcba
			SEVEN_SEGMENT_PORT=0b10011001;
			break;

			case 5:
							   //.gfedcba
			SEVEN_SEGMENT_PORT=0b10010010;
			break;

			case 6:
							   //.gfedcba
			SEVEN_SEGMENT_PORT=0b10000010;
			break;

			case 7:
						       //.gfedcba
			SEVEN_SEGMENT_PORT=0b11111000;
			break;

			case 8:
			SEVEN_SEGMENT_PORT=0b10000000;
			break;

			case 9:
						       //.gfedcba
			SEVEN_SEGMENT_PORT=0b10010000;
			break;
		}
		if(dp)
		{
			//if decimal point should be displayed

			//make 7th bit Low
			SEVEN_SEGMENT_PORT&=0b01111111;
		}
	}
	else
	{
		//This symbol on display tells that n was greater than 9
		//so display can't handle it

		SEVEN_SEGMENT_PORT=0b11111101;
	}
}


void main()
{
	//Setup io port direction as output
	SEVEN_SEGMENT_DDR=0xFF;    //All output
	
	//turn off all leds
	SEVEN_SEGMENT_PORT=0xFF;   //All segments off

	uint8_t count=0;

	while(1)
	{
		SevenSegment(count,0);

		count++;
		if(count==10)
		{
			count=0;
		}

		_delay_ms(1000);
	}
}

